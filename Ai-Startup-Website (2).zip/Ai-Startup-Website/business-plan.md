# BÁO CÁO CUỐI KỲ: DỰ ÁN KHỞI NGHIỆP VỚI AI

# **Tên nhóm: Những con AI**

# **Tên dự án:** PRiM – Creative Content for Students

# Thành viên

[24040021 Trần Thị Cẩm Ly](24040021%20Tr%E1%BA%A7n%20Th%E1%BB%8B%20C%E1%BA%A9m%20Ly%203eb66ad4b0a4806e8b67f3eb7b7cb82d.md)

[24040053 Lê Hoàng Sông Thư](24040053%20L%C3%AA%20Ho%C3%A0ng%20S%C3%B4ng%20Th%C6%B0%203eb66ad4b0a480feab60f2b8ebf24916.md)

[24040013 Võ Thị Trúc Linh](24040013%20V%C3%B5%20Th%E1%BB%8B%20Tr%C3%BAc%20Linh%203eb66ad4b0a48012981cf468ad15da10.md)

[24040011 Hoàng Ngọc Tú Quyên](24040011%20Ho%C3%A0ng%20Ng%E1%BB%8Dc%20T%C3%BA%20Quy%C3%AAn%203eb66ad4b0a48081b462e3b27e20037f.md)

## 0. Tóm tắt dự án

- **Ý tưởng kinh doanh trong 2–3 câu:**

PRiM – Creative Content for Students là dự án cung cấp dịch vụ truyền thông hướng đến sinh viên, các câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. Dự án tập trung cung cấp các sản phẩm như thiết kế poster, banner, thiệp mời, viết nội dung cho Facebook, TikTok, Instagram, xây dựng kịch bản video ngắn và các combo truyền thông với mức chi phí phù hợp với ngân sách của sinh viên.

Ý tưởng PRiM xuất phát từ thực tế nhiều sinh viên thường xuyên có nhu cầu thực hiện các sản phẩm truyền thông cho bài tập, sự kiện, hoạt động câu lạc bộ hoặc hoạt động kinh doanh cá nhân nhưng còn hạn chế về kỹ năng, thời gian và ngân sách. Khi tự thực hiện, khách hàng có thể mất nhiều thời gian nhưng sản phẩm chưa đạt được tính chuyên nghiệp; trong khi đó, việc thuê các đơn vị truyền thông chuyên nghiệp lại có thể vượt quá khả năng tài chính của sinh viên.

Vì vậy, PRiM hướng đến việc thu hẹp khoảng cách giữa hai nhu cầu trên bằng cách cung cấp dịch vụ truyền thông có chi phí vừa phải nhưng vẫn đảm bảo tính sáng tạo, chuyên nghiệp và phù hợp với môi trường sinh viên.

- **Khách hàng mục tiêu:**

Khách hàng mục tiêu của PRiM chủ yếu là sinh viên trong độ tuổi từ 18–24, các nhóm sinh viên, câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. Đây là nhóm khách hàng thường xuyên sử dụng Facebook, TikTok và Instagram, đồng thời có nhu cầu về hình ảnh đẹp, nội dung sáng tạo và bắt kịp xu hướng.

Đặc điểm nổi bật của nhóm khách hàng này là ngân sách dành cho truyền thông còn hạn chế và không phải ai cũng có kiến thức chuyên môn về thiết kế, viết nội dung hay xây dựng kế hoạch truyền thông. Bên cạnh đó, khách hàng thường cần sản phẩm trong thời gian tương đối ngắn để phục vụ bài tập, sự kiện hoặc hoạt động kinh doanh cá nhân.

- **Vấn đề cần giải quyết:**

Vấn đề cốt lõi mà PRiM hướng đến giải quyết là khách hàng cần những sản phẩm truyền thông đẹp, sáng tạo và chuyên nghiệp nhưng ngân sách còn hạn chế. Sinh viên có thể tự thiết kế bằng Canva, tìm kiếm ý tưởng trên Internet hoặc nhờ bạn bè hỗ trợ. Tuy nhiên, những phương án này có thể mất nhiều thời gian hoặc chưa đảm bảo chất lượng. Một lựa chọn khác là thuê freelancer hoặc agency nhưng chi phí có thể cao so với khả năng tài chính của sinh viên.

PRiM giải quyết vấn đề này bằng việc cung cấp dịch vụ truyền thông phù hợp với ngân sách, đồng thời hỗ trợ khách hàng từ khâu lên ý tưởng, viết nội dung đến thiết kế và xây dựng kịch bản. Qua đó, khách hàng có thể tiết kiệm thời gian, chi phí và nâng cao chất lượng sản phẩm truyền thông.

- **Sản phẩm / dịch vụ:**

PRiM cung cấp nhiều loại hình dịch vụ truyền thông, bao gồm thiết kế poster, banner, thiệp mời; viết nội dung cho Facebook, TikTok và Instagram; lên ý tưởng và viết kịch bản video ngắn; thiết kế nội dung cho sự kiện, câu lạc bộ và xây dựng các combo truyền thông với mức giá phù hợp với sinh viên.

Việc kết hợp nhiều dịch vụ trong cùng một hệ thống giúp khách hàng có thể sử dụng dịch vụ trọn gói thay vì phải tìm kiếm nhiều người khác nhau cho từng công việc. Đây cũng là một trong những giá trị mà PRiM hướng đến để tiết kiệm thời gian và tạo sự thuận tiện cho khách hàng.

- **Điểm khác biệt chính:**

Điểm khác biệt của PRiM nằm ở việc **tập trung chuyên biệt vào sinh viên và những khách hàng có ngân sách nhỏ**. Thay vì cạnh tranh trực tiếp với các agency lớn, PRiM xây dựng dịch vụ dựa trên mức giá phù hợp, cách làm việc linh hoạt và sự am hiểu về môi trường học tập, sự kiện sinh viên và mạng xã hội.

Bên cạnh đó, PRiM sử dụng AI để hỗ trợ tìm kiếm ý tưởng, viết nội dung và tạo bản nháp nhằm rút ngắn thời gian thực hiện. Tuy nhiên, nhóm không sử dụng AI để tạo sản phẩm cuối cùng một cách hoàn toàn tự động mà vẫn có người kiểm tra, chỉnh sửa và chịu trách nhiệm trước khi bàn giao cho khách hàng. Điều này giúp duy trì sự phù hợp với yêu cầu cụ thể và tính sáng tạo của sản phẩm.

- **Doanh thu và lợi nhuận hoạt động dự kiến / tháng (ghi rõ giả định):**

Có thể xây dựng giả định ban đầu theo hướng PRiM tập trung vào các đơn hàng nhỏ và combo truyền thông dành cho sinh viên. Do khách hàng mục tiêu có ngân sách hạn chế, doanh thu trên từng đơn hàng có thể không cao; vì vậy, mô hình cần hướng đến việc tăng số lượng đơn hàng, khuyến khích khách hàng sử dụng combo và tối ưu thời gian thực hiện nhờ AI. Tài liệu xác định chi phí khởi nghiệp ban đầu khoảng **5.000.000 đồng**, chủ yếu dành cho thiết kế, quảng bá trên mạng xã hội, phần mềm, in ấn và các chi phí vận hành ban đầu.

Do đó, khi hoàn thiện kế hoạch tài chính, nhóm cần tiếp tục xác định rõ giá từng gói dịch vụ, số lượng khách hàng dự kiến mỗi tháng và các chi phí phát sinh để tính doanh thu và lợi nhuận chính xác hơn.

- **Quyết định cuối cùng:** ĐIỀU CHỈNH VÀ TIẾP TỤ

Sau khi nghiên cứu khách hàng, sản phẩm, thị trường, đối thủ cạnh tranh và phân tích SWOT, nhóm nhận thấy ý tưởng PRiM vẫn có cơ sở để tiếp tục phát triển. Tuy nhiên, nhóm không giữ nguyên ý tưởng ban đầu mà điều chỉnh theo hướng tập trung rõ hơn vào sinh viên, câu lạc bộ và những khách hàng có ngân sách nhỏ.

Việc điều chỉnh này giúp PRiM tránh phải cạnh tranh trực tiếp với những agency lớn và tập trung vào những giá trị phù hợp với nguồn lực hiện tại như giá hợp lý, dịch vụ trọn gói, thời gian linh hoạt và sự am hiểu nhu cầu của sinh viên.

- **Căn cứ quan trọng nhất cho quyết định:**

Căn cứ quan trọng nhất là nhu cầu thực tế của nhóm khách hàng mục tiêu kết hợp với khả năng đáp ứng của PRiM. Sinh viên thường xuyên có nhu cầu về poster, nội dung mạng xã hội, video và các sản phẩm truyền thông cho bài tập, sự kiện, câu lạc bộ hoặc hoạt động kinh doanh. Trong khi đó, ngân sách và kỹ năng chuyên môn của nhóm khách hàng này còn hạn chế.

Bên cạnh đó, thị trường truyền thông số và mạng xã hội tại Việt Nam tạo ra môi trường phù hợp cho mô hình dịch vụ của PRiM. Tuy nhiên, dự án cũng phải đối mặt với sự cạnh tranh từ freelancer, agency, Canva và các công cụ AI. Vì vậy, nhóm xác định không nên chỉ bán sản phẩm thiết kế mà cần tập trung vào giá trị tiết kiệm thời gian, hỗ trợ ý tưởng, dịch vụ trọn gói, cá nhân hóa và mức giá phù hợp với sinh viên.

## 1. Ý tưởng khởi nghiệp

1. **Mô tả ngắn gọn ý tưởng:**

PRiM là dịch vụ truyền thông dành cho sinh viên, câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. Dự án cung cấp các sản phẩm và dịch vụ như thiết kế poster, banner, thiệp mời, viết nội dung mạng xã hội, xây dựng kịch bản video và combo truyền thông với mức giá phù hợp với ngân sách của khách hàng.

Điểm cốt lõi của PRiM là kết hợp giữa **AI và sự kiểm soát của con người**. AI được sử dụng để hỗ trợ nghiên cứu, phát triển ý tưởng, viết nội dung và tạo bản nháp nhanh; sau đó, con người sẽ kiểm tra và chỉnh sửa để đảm bảo sản phẩm phù hợp với yêu cầu của khách hàng.

1. **Nhóm muốn bán sản phẩm hoặc cung cấp dịch vụ gì?** 

PRiM cung cấp dịch vụ truyền thông với nhiều hình thức khác nhau. Các dịch vụ chính bao gồm thiết kế poster, banner và thiệp mời; viết nội dung cho Facebook, TikTok và Instagram; lên ý tưởng và viết kịch bản video ngắn; xây dựng nội dung truyền thông cho sự kiện, câu lạc bộ và cung cấp các combo truyền thông.

Trong quá trình phát triển, PRiM có thể xây dựng nhiều gói dịch vụ khác nhau dựa trên nhu cầu và ngân sách của khách hàng. Đặc biệt, việc kết hợp thiết kế, content và kịch bản thành một combo giúp khách hàng thuận tiện hơn và tạo thêm giá trị so với việc chỉ cung cấp từng dịch vụ riêng lẻ.

1. **Vì sao nhóm lựa chọn ý tưởng này?**

Nhóm lựa chọn ý tưởng PRiM vì nhận thấy nhu cầu sử dụng các sản phẩm truyền thông của sinh viên xuất hiện khá thường xuyên. Trong quá trình học tập và tham gia các hoạt động ngoại khóa, sinh viên thường phải thực hiện poster, bài đăng mạng xã hội, video, nội dung sự kiện hoặc các sản phẩm truyền thông khác.

Tuy nhiên, không phải sinh viên nào cũng có đủ kỹ năng thiết kế, viết nội dung hoặc thời gian để tự thực hiện. Trong khi đó, chi phí thuê các dịch vụ chuyên nghiệp có thể vượt quá ngân sách của sinh viên. Ý tưởng PRiM vì vậy vừa xuất phát từ một nhu cầu thực tế, vừa phù hợp với kiến thức chuyên ngành PR của nhóm.

1. **AI đã hỗ trợ phát triển hoặc cải thiện ý tưởng như thế nào?**

AI đóng vai trò là công cụ hỗ trợ nhóm trong nhiều giai đoạn phát triển dự án. Trước hết, AI giúp nhóm tìm kiếm và phát triển ý tưởng kinh doanh, xác định khách hàng mục tiêu và phân tích nhu cầu của khách hàng. Ngoài ra, AI còn hỗ trợ đề xuất tên dự án, slogan, xây dựng nội dung truyền thông và đưa ra những hướng cải thiện cho mô hình kinh doanh.

Trong quá trình hoàn thiện sản phẩm, nhóm sử dụng AI để hỗ trợ lên ý tưởng, viết nội dung và tạo bản nháp nhanh. Điều này giúp tiết kiệm thời gian và tăng khả năng phục vụ nhiều khách hàng hơn. Tuy nhiên, nhóm không phụ thuộc hoàn toàn vào AI mà vẫn duy trì bước kiểm tra và chỉnh sửa của con người nhằm đảm bảo chất lượng và sự phù hợp của sản phẩm

1. **Điểm hấp dẫn nhất của ý tưởng là gì? Vì sao?** 

Điểm hấp dẫn nhất của PRiM là cung cấp dịch vụ truyền thông phù hợp với ngân sách sinh viên nhưng vẫn giúp khách hàng tiết kiệm thời gian và có được sản phẩm sáng tạo, chuyên nghiệp. Đây là giá trị phù hợp trực tiếp với khó khăn lớn nhất của khách hàng mục tiêu.

PRiM không chỉ cung cấp một sản phẩm riêng lẻ mà hướng đến mô hình dịch vụ trọn gói, kết hợp giữa lên ý tưởng, viết content, thiết kế và xây dựng kịch bản. Nhờ đó, khách hàng không phải tìm kiếm nhiều đơn vị khác nhau cho từng công việc. Đồng thời, việc ứng dụng AI giúp PRiM rút ngắn thời gian thực hiện, trong khi con người vẫn kiểm tra và hoàn thiện sản phẩm cuối cùng.

Tóm lại, PRiM có thể tiếp tục phát triển nhưng cần đi theo hướng “dịch vụ truyền thông trọn gói dành cho sinh viên”, thay vì trở thành một dịch vụ thiết kế thông thường**.** Đây cũng là hướng giúp dự án tạo sự khác biệt trước Canva, freelancer và các đơn vị truyền thông trên thị trường.

## 2. Khách hàng mục tiêu và vấn đề

| Nội dung | Câu trả lời của nhóm | Căn cứ / nguồn nếu có |
| --- | --- | --- |
| Khách hàng mục tiêu là ai? | Khách hàng mục tiêu của PRiM là sinh viên từ 18–24 tuổi, các nhóm sinh viên, câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. | Phân tích khách hàng mục tiêu của nhóm. |
| Đặc điểm chính của khách hàng | Khách hàng thường xuyên sử dụng Facebook, TikTok và Instagram; có nhu cầu thiết kế và đăng nội dung truyền thông; ngân sách còn hạn chế; chưa có nhiều kinh nghiệm về thiết kế và truyền thông; thường cần sản phẩm nhanh và quan tâm đến nội dung đẹp, sáng tạo, phù hợp xu hướng. | Nội dung phân tích chân dung khách hàng của PRiM. |
| Vấn đề hoặc khó khăn | Khách hàng gặp khó khăn trong việc lên ý tưởng, viết nội dung và thiết kế sản phẩm truyền thông. Khi tự thực hiện có thể mất nhiều thời gian nhưng sản phẩm chưa chuyên nghiệp; trong khi thuê dịch vụ bên ngoài có thể vượt quá ngân sách của sinh viên | Phân tích vấn đề khách hàng |
| Vì sao vấn đề đáng giải quyết? | Vấn đề này xuất hiện thường xuyên khi sinh viên làm bài tập, tổ chức sự kiện, hoạt động câu lạc bộ hoặc kinh doanh online. Việc giải quyết vấn đề giúp khách hàng tiết kiệm thời gian, giảm chi phí và nâng cao chất lượng sản phẩm truyền thông. | Phân tích mức độ cần thiết của vấn đề. |
| Cách khách hàng đang giải quyết vấn đề | Khách hàng thường tự thiết kế bằng Canva, tự tìm ý tưởng và nội dung trên Internet, nhờ bạn bè hỗ trợ hoặc thuê freelancer và các đơn vị thiết kế, truyền thông. | Các phương án khách hàng đang sử dụng. |

## 3. Sản phẩm hoặc dịch vụ

- **Mô tả sản phẩm / dịch vụ:**

PRiM – Creative Content for Students là dịch vụ truyền thông được xây dựng nhằm phục vụ chủ yếu cho sinh viên, các câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. Dự án cung cấp các sản phẩm và dịch vụ truyền thông đa dạng, đáp ứng những nhu cầu phổ biến của khách hàng trong quá trình học tập, tổ chức hoạt động và kinh doanh trên môi trường số.

Cụ thể, PRiM cung cấp các dịch vụ như thiết kế poster, banner, thiệp mời; viết nội dung cho các nền tảng Facebook, TikTok và Instagram; lên ý tưởng và viết kịch bản cho video ngắn; thiết kế nội dung truyền thông cho sự kiện, câu lạc bộ; đồng thời xây dựng các combo truyền thông với mức giá phù hợp với ngân sách của sinh viên. Việc cung cấp nhiều dịch vụ trong cùng một hệ thống giúp khách hàng có thể giải quyết nhiều nhu cầu truyền thông thay vì phải tìm kiếm nhiều người hoặc nhiều đơn vị khác nhau cho từng công việc.

Bên cạnh các dịch vụ trên, PRiM còn định hướng xây dựng nhiều gói dịch vụ khác nhau dựa trên nhu cầu và khả năng chi trả của khách hàng. Nhóm cũng lựa chọn sử dụng AI như một công cụ hỗ trợ trong quá trình lên ý tưởng, viết nội dung và tạo bản nháp nhằm rút ngắn thời gian thực hiện. Tuy nhiên, AI không được sử dụng để thay thế hoàn toàn con người trong việc tạo ra sản phẩm cuối cùng. Sau khi có bản nháp, nhóm vẫn kiểm tra, chỉnh sửa và hoàn thiện trước khi bàn giao cho khách hàng

- **Vấn đề khách hàng được giải quyết:**

PRiM được xây dựng để giải quyết vấn đề khách hàng có nhu cầu thực hiện các hoạt động truyền thông nhưng còn hạn chế về kỹ năng, thời gian và ngân sách. Đối tượng khách hàng của PRiM thường cần thực hiện poster, nội dung mạng xã hội, video hoặc các sản phẩm truyền thông khác cho bài tập, sự kiện, hoạt động câu lạc bộ và kinh doanh online. Tuy nhiên, không phải khách hàng nào cũng có kiến thức chuyên môn về thiết kế và truyền thông để có thể tự thực hiện một cách hiệu quả.

Khi tự thực hiện, khách hàng có thể phải mất nhiều thời gian để tìm ý tưởng, viết nội dung, thiết kế hình ảnh và hoàn thiện sản phẩm nhưng kết quả chưa chắc đạt được sự chuyên nghiệp. Một số khách hàng lựa chọn thuê freelancer hoặc các đơn vị truyền thông bên ngoài để giải quyết vấn đề này, nhưng chi phí có thể cao so với khả năng tài chính của sinh viên. Vì vậy, PRiM hướng đến việc tạo ra một giải pháp ở giữa hai lựa chọn này: khách hàng không cần tự làm hoàn toàn nhưng cũng không phải bỏ ra mức chi phí quá cao cho các dịch vụ chuyên nghiệp.

Thông qua dịch vụ trọn gói, PRiM hỗ trợ khách hàng từ khâu lên ý tưởng, viết nội dung, thiết kế đến xây dựng kịch bản. Nhờ đó, khách hàng có thể giảm bớt thời gian và công sức dành cho việc tự thực hiện truyền thông, đồng thời vẫn có được sản phẩm phù hợp với nhu cầu của mình.

- **Lợi ích khách hàng nhận được:**

Khi sử dụng dịch vụ của PRiM, khách hàng có thể nhận được nhiều lợi ích thiết thực. Trước hết, dịch vụ giúp khách hàng tiết kiệm thời gian vì không phải tự thực hiện tất cả các công việc từ tìm ý tưởng, viết nội dung đến thiết kế sản phẩm. Điều này đặc biệt phù hợp với sinh viên, những người thường phải thực hiện nhiều bài tập, hoạt động nhóm, sự kiện hoặc công việc cá nhân cùng lúc.

Bên cạnh đó, PRiM giúp tiết kiệm chi phí thông qua việc định hướng mức giá phù hợp với ngân sách của sinh viên. Khách hàng vẫn có thể tiếp cận các sản phẩm truyền thông được thiết kế và xây dựng nội dung một cách chuyên nghiệp mà không cần thuê những đơn vị có chi phí quá cao.

Một lợi ích khác là khách hàng được hỗ trợ về ý tưởng khi chưa biết bắt đầu từ đâu. Đây là điểm có ý nghĩa đối với những sinh viên hoặc nhóm nhỏ chưa có nhiều kinh nghiệm về truyền thông. Thay vì chỉ nhận một sản phẩm thiết kế đơn lẻ, khách hàng có thể được hỗ trợ xuyên suốt quá trình từ ý tưởng, nội dung đến sản phẩm hoàn chỉnh.

Ngoài ra, hình thức dịch vụ trọn gói của PRiM còn giúp khách hàng thuận tiện hơn trong quá trình thực hiện. Khách hàng không cần tìm nhiều người khác nhau cho từng công việc như viết content, thiết kế poster hay xây dựng kịch bản mà có thể sử dụng nhiều dịch vụ từ cùng một đơn vị.

- **Điểm khác biệt chính:**

Điểm khác biệt quan trọng nhất của PRiM là tập trung chuyên biệt vào nhóm khách hàng sinh viên và những khách hàng có ngân sách nhỏ, thay vì phục vụ đại trà. Từ việc xác định rõ khách hàng mục tiêu, PRiM xây dựng mức giá vừa phải, cách làm việc linh hoạt và nội dung phù hợp với môi trường học tập, sự kiện sinh viên cũng như các nền tảng mạng xã hội.

Ngoài yếu tố khách hàng mục tiêu, PRiM còn tạo sự khác biệt bằng việc cung cấp dịch vụ trọn gói, kết hợp giữa thiết kế, content, kịch bản video và các hoạt động truyền thông. Điều này giúp PRiM không chỉ bán một sản phẩm riêng lẻ mà hướng đến việc giải quyết nhiều nhu cầu truyền thông của khách hàng cùng lúc. Đây cũng là khoảng trống mà nhóm xác định có thể khai thác khi khách hàng thường gặp khó khăn trong việc tự lên ý tưởng, viết nội dung và hoàn thiện sản phẩm.

Một điểm khác biệt nữa là PRiM ứng dụng AI kết hợp với kiểm soát của con người. AI được sử dụng để hỗ trợ tìm ý tưởng, viết nội dung và tạo bản nháp nhanh, qua đó giúp tăng tốc độ thực hiện và nâng cao khả năng phục vụ khách hàng. Tuy nhiên, nhóm không hoàn toàn phụ thuộc vào AI mà vẫn có người kiểm tra và chỉnh sửa sản phẩm cuối cùng để đảm bảo phù hợp với yêu cầu cụ thể của từng khách hàng và duy trì tính sáng tạo.

- **Lý do quan trọng nhất khiến khách hàng lựa chọn sản phẩm / dịch vụ:**

Lý do quan trọng nhất khiến khách hàng lựa chọn PRiM là dịch vụ có mức chi phí phù hợp với ngân sách sinh viên nhưng vẫn mang lại sản phẩm truyền thông có tính sáng tạo và chuyên nghiệp. Đây chính là điểm giải quyết trực tiếp vấn đề cốt lõi của khách hàng mục tiêu: có nhu cầu truyền thông thường xuyên nhưng hạn chế về tài chính, thời gian và kỹ năng chuyên môn.

Bên cạnh yếu tố chi phí, khách hàng còn có thể lựa chọn PRiM vì sự thuận tiện của dịch vụ trọn gói. PRiM không chỉ cung cấp một sản phẩm thiết kế mà có thể hỗ trợ từ việc lên ý tưởng, viết nội dung, xây dựng kịch bản đến thiết kế sản phẩm. Điều này giúp khách hàng tiết kiệm thời gian và giảm bớt khó khăn trong quá trình triển khai hoạt động truyền thông.

Vì vậy, giá trị mà PRiM hướng đến không đơn thuần là “làm một poster” hay “viết một bài content”, mà là cung cấp một giải pháp truyền thông phù hợp với nhu cầu và khả năng tài chính của sinh viên. Sự kết hợp giữa giá phù hợp, dịch vụ trọn gói, cá nhân hóa, tiết kiệm thời gian và ứng dụng AI có kiểm soát bởi con người là nền tảng tạo nên giá trị của PRiM.

## 4. Nghiên cứu thị trường và kiểm chứng

- **Thị trường nhóm muốn tham gia:**

PRiM hướng đến tham gia vào thị trường dịch vụ truyền thông và sáng tạo nội dung số, tập trung vào nhóm khách hàng trẻ, đặc biệt là sinh viên, câu lạc bộ, nhóm tổ chức sự kiện và những cá nhân kinh doanh online nhỏ. Đây là thị trường gắn liền với sự phát triển của Internet, mạng xã hội và các hoạt động kinh doanh trên môi trường số.

Theo nội dung nghiên cứu của nhóm, vào đầu năm 2025, Việt Nam có khoảng 79,8 triệu người sử dụng Internet và 76,2 triệu social media user identities. Những con số này cho thấy môi trường số và mạng xã hội có phạm vi tiếp cận lớn, tạo điều kiện cho nhu cầu về nội dung, hình ảnh và các hoạt động truyền thông trực tuyến phát triển.

Bên cạnh đó, PRiM không định hướng cạnh tranh trực tiếp với các agency lớn mà tập trung khai thác thị trường ngách là sinh viên và những khách hàng có ngân sách nhỏ. Cách tiếp cận này phù hợp hơn với nguồn lực ban đầu của nhóm và với đặc điểm của khách hàng mục tiêu.

- **Nhu cầu chính của khách hàng:**

Qua quá trình nghiên cứu, nhóm xác định khách hàng mục tiêu của PRiM có một số nhu cầu chính. Trước hết, khách hàng cần thiết kế hình ảnh đẹp, nhanh và phù hợp với các nền tảng mạng xã hội. Đây là nhu cầu thường xuyên đối với sinh viên, câu lạc bộ và những cá nhân kinh doanh online khi cần quảng bá một hoạt động, sự kiện hoặc sản phẩm.

Bên cạnh hình ảnh, khách hàng cũng có nhu cầu viết nội dung ngắn gọn, dễ tiếp cận, đặc biệt là nội dung dành cho Facebook, TikTok và Instagram. Ngoài ra, khách hàng có nhu cầu được hỗ trợ ý tưởng cho video TikTok/Reels và hỗ trợ xây dựng nội dung khi chưa có nhiều kinh nghiệm về truyền thông. Một yếu tố quan trọng khác là mức giá dịch vụ phải phù hợp với ngân sách sinh viên, bởi đây là nhóm khách hàng có khả năng chi trả còn hạn chế.

Như vậy, nhu cầu của khách hàng không chỉ dừng lại ở việc mua một sản phẩm thiết kế riêng lẻ mà còn bao gồm nhu cầu được hỗ trợ xuyên suốt quá trình từ ý tưởng, nội dung đến sản phẩm truyền thông hoàn chỉnh.

- **Xu hướng quan trọng:**

Một xu hướng quan trọng của thị trường là nội dung số và mạng xã hội ngày càng giữ vai trò quan trọng trong hoạt động truyền thông. Theo nghiên cứu trong file, Việt Nam có 76,2 triệu social media user identities vào tháng 1/2025; dữ liệu quảng cáo của TikTok cũng ghi nhận khoảng 40,9 triệu người dùng từ 18 tuổi trở lên tại Việt Nam. Điều này cho thấy các nền tảng mạng xã hội đang là môi trường quan trọng để cá nhân, nhóm sinh viên và hoạt động kinh doanh tiếp cận công chúng.

Xu hướng thứ hai là hoạt động kinh doanh và truyền thông ngày càng gắn với môi trường số. Theo nội dung nhóm kiểm chứng, Bộ Công Thương cho biết quy mô thương mại điện tử Việt Nam năm 2025 đạt khoảng 31 tỷ USD, tăng 25,5% so với năm trước. Sự phát triển của thương mại điện tử tạo thêm nhu cầu về hình ảnh, nội dung và các hoạt động truyền thông số, đặc biệt đối với những cá nhân và người kinh doanh nhỏ.

Ngoài ra, nhóm cũng nhận thấy nhu cầu truyền thông của sinh viên xuất hiện tương đối thường xuyên do họ liên tục tham gia các hoạt động như làm bài tập, tổ chức sự kiện, hoạt động câu lạc bộ và kinh doanh online. Điều này tạo ra khả năng hình thành nhu cầu sử dụng dịch vụ lặp lại

- **Cơ hội:**

Cơ hội lớn của PRiM nằm ở việc tập trung vào một thị trường ngách cụ thể là sinh viên và khách hàng có ngân sách nhỏ. Thay vì phải cạnh tranh về quy mô với các agency chuyên nghiệp, PRiM có thể tập trung xây dựng dịch vụ phù hợp hơn với nhu cầu và khả năng chi trả của nhóm khách hàng này.

Theo phân tích của nhóm, PRiM có thể khai thác một số lợi thế như giá phù hợp với sinh viên, dịch vụ đơn giản và dễ đặt, thời gian thực hiện linh hoạt, hiểu nhu cầu và môi trường sinh viên. Bên cạnh đó, việc sử dụng AI để hỗ trợ lên ý tưởng và tạo bản nháp nhanh có thể giúp nhóm tiết kiệm thời gian và tăng khả năng phục vụ nhiều khách hàng hơn.

Một cơ hội khác đến từ sự phát triển của mạng xã hội và kinh doanh online. Khi cá nhân, câu lạc bộ và nhóm kinh doanh nhỏ ngày càng sử dụng các nền tảng số để truyền thông, nhu cầu về poster, content, video ngắn và các sản phẩm truyền thông khác cũng có điều kiện phát triển.

- **Rủi ro / vấn đề thị trường:**

Mặc dù có cơ hội phát triển, PRiM cũng phải đối mặt với nhiều rủi ro trên thị trường. Trước hết là mức độ cạnh tranh cao, bởi hiện nay có nhiều freelancer và dịch vụ thiết kế, truyền thông cùng cung cấp những sản phẩm tương tự. Điều này khiến PRiM cần tạo ra sự khác biệt rõ ràng để thu hút và duy trì khách hàng.

Một thách thức đáng chú ý khác là AI và Canva có thể trở thành sản phẩm thay thế cho dịch vụ của PRiM. Khách hàng hoàn toàn có thể tự sử dụng các công cụ này để tạo content hoặc thiết kế thay vì thuê dịch vụ. Vì vậy, nếu PRiM chỉ cung cấp các sản phẩm thiết kế đơn giản thì khả năng bị thay thế sẽ cao hơn.

Ngoài ra, ngân sách thấp của khách hàng mục tiêu cũng là một vấn đề cần lưu ý. Phần lớn khách hàng là sinh viên nên giá trị mỗi đơn hàng có thể không cao, gây khó khăn trong việc tạo doanh thu lớn nếu chỉ dựa vào những đơn hàng nhỏ. Đồng thời, xu hướng trên mạng xã hội thay đổi nhanh khiến PRiM phải thường xuyên cập nhật cách làm nội dung để tránh bị lỗi thời.

Một rủi ro khác liên quan đến chất lượng sản phẩm. Nếu dự án phụ thuộc quá nhiều vào AI mà thiếu sự kiểm tra của con người, nội dung có thể thiếu tính sáng tạo hoặc không phù hợp với yêu cầu cụ thể của khách hàng. Vì vậy, nhóm xác định AI chỉ nên đóng vai trò công cụ hỗ trợ, còn sản phẩm cuối cùng vẫn cần được con người kiểm tra và chỉnh sửa.

### Kiểm tra ít nhất 2 thông tin quan trọng bằng nguồn ngoài AI

| Thông tin cần kiểm tra | Nguồn, liên kết và ngày truy cập | Nguồn nói gì? | Kết luận của nhóm |
| --- | --- | --- | --- |
| 1. Số lượng người sử dụng Internet tại Việt Nam | DataReportal – Global Digital Insights. Số liệu đầu năm 2025. | Việt Nam có khoảng 79,8 triệu người sử dụng Internet vào đầu năm 2025. | Chưa xác nhận. Điều này cho thấy môi trường Internet tại Việt Nam có lượng người sử dụng lớn, tạo điều kiện cho các hoạt động truyền thông số của PRiM |
| Mức độ cạnh tranh của thị trường dịch vụ truyền thông | Phân tích thị trường và đối thủ trong tài liệu của nhóm. | Thị trường có nhiều freelancer và dịch vụ thiết kế, truyền thông. Ngoài ra, khách hàng có thể tự sử dụng AI và Canva để tạo nội dung hoặc thiết kế thay vì thuê dịch vụ. | Được xác nhận trong phân tích của nhóm. Đây là rủi ro cạnh tranh quan trọng, vì PRiM không chỉ phải cạnh tranh với freelancer và agency mà còn với các công cụ mà khách hàng có thể tự sử dụng.chỉnh; giải thích] |

**Sau nghiên cứu, ý tưởng ban đầu còn đáng để tiếp tục không? Vì sao?** 

Có, ý tưởng PRiM vẫn đáng để tiếp tục. Số lượng người sử dụng Internet tại Việt Nam lớn, với khoảng 79,8 triệu người dùng Internet vào đầu năm 2025, cho thấy môi trường truyền thông số có phạm vi tiếp cận rộng và tạo điều kiện cho các dịch vụ truyền thông trực tuyến phát triển.

Tuy nhiên, thị trường dịch vụ truyền thông có mức độ cạnh tranh cao do có nhiều freelancer và dịch vụ thiết kế, đồng thời khách hàng có thể tự sử dụng AI và Canva để tạo nội dung. Vì vậy, nhóm sẽ điều chỉnh ý tưởng theo hướng tập trung vào sinh viên và khách hàng có ngân sách nhỏ, cung cấp dịch vụ trọn gói với giá phù hợp, tiết kiệm thời gian và vẫn có sự kiểm tra của con người.

Kết luận: ĐIỀU CHỈNH VÀ TIẾP TỤC.

## 5. Phân tích đối thủ cạnh tranh

| Đối thủ | Sản phẩm / dịch vụ | Khách hàng của họ | Điểm mạnh | Điểm yếu / khoảng trống | Dự án của nhóm khác ở đâu? | Nguồn |
| --- | --- | --- | --- | --- | --- | --- |
| Canva | Công cụ thiết kế trực tuyến, cho phép người dùng tự tạo các sản phẩm thiết kế. | Sinh viên, cá nhân và những người có nhu cầu tự thiết kế nội dung truyền thông. | Chi phí thấp hoặc gần như không cần thuê dịch vụ; khách hàng có thể tự thiết kế theo nhu cầu. | Khách hàng phải tự lên ý tưởng, viết nội dung, thiết kế và hoàn thiện sản phẩm. Canva chủ yếu cung cấp công cụ chứ không trực tiếp hỗ trợ toàn bộ quá trình truyền thông. | PRiM cung cấp dịch vụ trọn gói gồm lên ý tưởng + content + thiết kế + kịch bản, giúp khách hàng tiết kiệm thời gian và được hỗ trợ khi chưa biết bắt đầu từ đâu. | [https://www.canva.com/solutions/visual-communication-tools/?utm_source=chatgpt.com](https://www.canva.com/solutions/visual-communication-tools/?utm_source=chatgpt.com) |
| Freelancer | Cung cấp các dịch vụ thiết kế và truyền thông cho khách hàng cá nhân. | Khách hàng cá nhân có nhu cầu thuê người thực hiện thiết kế và truyền thông. | Đã có sẵn dịch vụ thiết kế và truyền thông; có thể đáp ứng các nhu cầu cụ thể của khách hàng. | Thị trường có nhiều freelancer và dịch vụ tương tự, tạo mức độ cạnh tranh cao. Chưa tập trung chuyên biệt vào sinh viên và khách hàng có ngân sách nhỏ. | PRiM tập trung rõ vào sinh viên, cung cấp các gói dịch vụ đơn giản, giá phù hợp và quy trình đặt dịch vụ dễ dàng hơn. | [https://www.upwork.com/?utm_source=chatgpt.com](https://www.upwork.com/?utm_source=chatgpt.com) |
| Agency / Đơn vị truyền thông chuyên nghiệp | Cung cấp các dịch vụ truyền thông chuyên nghiệp cho khách hàng. | Các cá nhân, tổ chức hoặc doanh nghiệp có nhu cầu sử dụng dịch vụ truyền thông chuyên | Có tính chuyên nghiệp và cung cấp dịch vụ truyền thông chuyên sâu. | Chi phí có thể cao so với ngân sách của sinh viên; nhóm cũng không có lợi thế về quy mô để cạnh tranh trực tiếp với các agency lớn. | PRiM không cạnh tranh bằng quy mô mà tập trung vào giá vừa phải, thời gian linh hoạt và hiểu môi trường sinh viên. | Phần này bám theo phân tích đối thủ trong file của nhóm. |

**Đối thủ tạo áp lực lớn nhất và lý do:** 

Freelancer và các dịch vụ thiết kế/truyền thông tự do tạo áp lực lớn nhất đối với PRiM vì có số lượng nhiều, cung cấp đa dạng dịch vụ thiết kế và sáng tạo nội dung, đồng thời khách hàng có thể dễ dàng tìm kiếm và so sánh nhiều người cung cấp. Bên cạnh đó, khách hàng còn có thể tự thiết kế bằng Canva hoặc sử dụng các công cụ AI, làm tăng khả năng thay thế dịch vụ của PRiM. Vì vậy, PRiM cần tạo khác biệt bằng cách tập trung vào sinh viên và khách hàng có ngân sách nhỏ, mức giá hợp lý, quy trình linh hoạt và cung cấp dịch vụ trọn gói từ ý tưởng, nội dung đến thiết kế. 

## 6. Phân tích SWOT

| Yếu tố | Nhận định cụ thể của nhóm | Căn cứ / ví dụ / nguồn | Tác động đến dự án |
| --- | --- | --- | --- |
| **S — Điểm mạnh** | PRiM tập trung vào sinh viên, CLB, nhóm sinh viên và người kinh doanh online nhỏ, cung cấp dịch vụ đa dạng gồm thiết kế, content, kịch bản và kế hoạch truyền thông với mức giá phù hợp. | Dự án xác định khách hàng mục tiêu là nhóm có ngân sách hạn chế và nhu cầu truyền thông thường xuyên. | Giúp PRiM tạo sự khác biệt, dễ điều chỉnh dịch vụ theo nhu cầu khách hàng và tránh cạnh tranh trực tiếp với các agency lớn. |
| **W — Điểm yếu** | Nguồn vốn và nguồn lực hạn chế là điểm yếu đáng chú ý. Vốn khởi nghiệp dự kiến khoảng 5 triệu đồng, trong khi nhóm còn hạn chế về nhân lực và kinh nghiệm thực tế. | Xác định nguồn vốn ban đầu thấp và số lượng thành viên hạn chế so với số lượng dịch vụ PRiM cung cấp. | Có thể gây khó khăn trong việc đầu tư marketing, phần mềm, nhân sự và xử lý nhiều đơn hàng cùng lúc, từ đó ảnh hưởng đến tiến độ và chất lượng dịch vụ. |
| **O — Cơ hội** | Thị trường ngách sinh viên còn tiềm năng, vì sinh viên thường có nhu cầu thiết kế poster, viết content, làm video và truyền thông cho bài tập, CLB, sự kiện hoặc kinh doanh online. | Ghi nhận nhu cầu hỗ trợ truyền thông của sinh viên xuất hiện thường xuyên và đề xuất tập trung vào nhóm khách hàng có ngân sách nhỏ. | Tạo cơ hội để PRiM xây dựng tệp khách hàng riêng, phát triển các gói dịch vụ phù hợp với ngân sách sinh viên và tăng khả năng tiếp cận thị trường. |
| **T — Thách thức** | Khách hàng có thể tự sử dụng AI và Canva để tạo content hoặc thiết kế thay vì thuê PRiM. Bên cạnh đó, thị trường có nhiều freelancer và dịch vụ truyền thông cạnh tranh. | Xác định AI và Canva là sản phẩm thay thế, đồng thời ghi nhận mức độ cạnh tranh cao trên thị trường. | Làm tăng áp lực cạnh tranh và nguy cơ khách hàng không sử dụng dịch vụ. PRiM cần nhấn mạnh giá trị mà công cụ tự làm khó thay thế như tiết kiệm thời gian, hỗ trợ ý tưởng, dịch vụ trọn gói và cá nhân hóa. |
- **Điểm mạnh quan trọng nhất và lý do:**

PRiM tập trung vào nhóm khách hàng sinh viên và khách hàng có ngân sách nhỏ, đồng thời cung cấp dịch vụ tương đối trọn gói từ lên ý tưởng, viết nội dung, thiết kế đến hỗ trợ kịch bản. Đây là điểm mạnh quan trọng vì nhóm khách hàng này thường có hạn chế về thời gian, kỹ năng và ngân sách, trong khi PRiM có thể cung cấp giải pháp phù hợp và linh hoạt

- **Điểm yếu nguy hiểm nhất và lý do:**

Điểm yếu đáng chú ý là PRiM còn là dự án mới, nguồn lực và kinh nghiệm thực tế còn hạn chế. Trong khi đó, khách hàng có nhiều lựa chọn như Canva, freelancer và các đơn vị truyền thông chuyên nghiệp. Điều này có thể khiến PRiM gặp khó khăn trong việc xây dựng uy tín và thu hút khách hàng ban đầu.

- **Cơ hội lớn nhất:**

Nhu cầu sử dụng Internet và mạng xã hội tại Việt Nam ngày càng lớn, tạo môi trường thuận lợi cho các dịch vụ sáng tạo nội dung và truyền thông số. Đặc biệt, sinh viên, câu lạc bộ, nhóm tổ chức sự kiện và các cá nhân kinh doanh online đều có nhu cầu tạo nội dung để quảng bá và tiếp cận người dùng.

- **Thách thức lớn nhất:**

Mức độ cạnh tranh cao trong lĩnh vực thiết kế và truyền thông. PRiM phải cạnh tranh với freelancer, agency và các công cụ như Canva, AI có khả năng hỗ trợ khách hàng tự tạo nội dung với chi phí thấp hoặc miễn phí.

- **Nhóm sẽ phản ứng như thế nào?**

Nhóm sẽ tập trung vào thị trường ngách là sinh viên và khách hàng có ngân sách nhỏ, thay vì cạnh tranh trực tiếp với các agency lớn. PRiM sẽ tạo sự khác biệt thông qua giá hợp lý, quy trình linh hoạt, hiểu môi trường sinh viên và cung cấp dịch vụ kết hợp giữa ý tưởng, nội dung và thiết kế. Đồng thời, nhóm sử dụng AI để hỗ trợ quá trình lên ý tưởng và tạo bản nháp nhưng vẫn có bước kiểm tra, chỉnh sửa của con người để đảm bảo chất lượng.

## 7. Năm áp lực cạnh tranh của Porter

| Áp lực cạnh tranh | Mức độ | Lý do cụ thể | Căn cứ / nguồn nếu có |
| --- | --- | --- | --- |
| Cạnh tranh giữa các đối thủ hiện tại | Cao | Thị trường dịch vụ thiết kế, content và truyền thông hiện có nhiều freelancer và các đơn vị cung cấp dịch vụ tương tự. Các dịch vụ như thiết kế poster, viết content, làm video tương đối phổ biến nên khách hàng có nhiều lựa chọn. Bên cạnh đó, các công cụ như Canva và AI cũng hỗ trợ khách hàng tự thực hiện một phần công việc. Vì vậy, PRiM phải tạo được sự khác biệt thay vì chỉ cạnh tranh bằng sản phẩm thiết kế. | Xác định cạnh tranh cao, thị trường có nhiều freelancer và dịch vụ thiết kế, truyền thông. PRiM cần tập trung vào sinh viên, giá phù hợp và dịch vụ trọn gói để tạo khác biệt. |
| Nguy cơ đối thủ mới gia nhập | Cao | Rào cản gia nhập thị trường tương đối thấp vì dịch vụ thiết kế, content và video không đòi hỏi nguồn vốn quá lớn để bắt đầu. Một cá nhân hoặc nhóm sinh viên có kỹ năng sử dụng Canva, AI và các công cụ sáng tạo nội dung cũng có thể cung cấp dịch vụ tương tự PRiM. Do đó, trong quá trình hoạt động, PRiM có thể phải đối mặt với sự xuất hiện của các freelancer hoặc nhóm sinh viên mới. | Nhận định các dịch vụ thiết kế, content và video tương đối dễ tiếp cận, vì vậy có thể xuất hiện thêm freelancer hoặc nhóm sinh viên cung cấp dịch vụ tương tự. |
| Quyền thương lượng của nhà cung cấp | Thấp | PRiM chủ yếu sử dụng các công cụ hỗ trợ cho hoạt động sáng tạo nội dung, thiết kế và AI. Nhóm có thể lựa chọn nhiều công cụ khác nhau thay vì phụ thuộc hoàn toàn vào một nhà cung cấp duy nhất. Vì vậy, khả năng nhà cung cấp gây sức ép trực tiếp lên hoạt động kinh doanh của PRiM được đánh giá là thấp. | PRiM sử dụng AI để hỗ trợ lên ý tưởng, viết nội dung và tạo bản nháp; AI đóng vai trò công cụ hỗ trợ chứ không phải sản phẩm cuối cùng. |
| Quyền thương lượng của khách hàng | Cao | Khách hàng mục tiêu của PRiM chủ yếu là sinh viên, CLB, nhóm sinh viên và người kinh doanh online nhỏ, trong đó phần lớn có ngân sách hạn chế. Đồng thời, khách hàng có nhiều lựa chọn khác như tự sử dụng Canva, AI, thuê freelancer hoặc sử dụng các dịch vụ truyền thông khác. Vì vậy, khách hàng có khả năng so sánh về giá, chất lượng và thời gian thực hiện khá cao. | Xác định khách hàng có ngân sách thấp và có thể tự sử dụng AI, Canva thay vì thuê dịch vụ. |
| Nguy cơ từ sản phẩm / dịch vụ thay thế | Cao | Đây là áp lực đáng kể đối với PRiM vì khách hàng có thể tự tạo poster, content hoặc một số nội dung truyền thông bằng Canva và AI thay vì thuê dịch vụ. Các công cụ này giúp khách hàng tiết kiệm chi phí và chủ động thực hiện công việc. Vì vậy, nếu PRiM chỉ cung cấp một sản phẩm đơn lẻ như thiết kế poster thì rất dễ bị thay thế. | Xác định rõ AI và Canva là sản phẩm thay thế, đồng thời khách hàng có thể tự sử dụng các công cụ này thay vì thuê PRiM. |

**Sau phân tích, thị trường có hấp dẫn để tham gia không? Vì sao?**
Có, thị trường vẫn có mức độ hấp dẫn để PRiM tham gia, nhưng nhóm cần lựa chọn đúng phân khúc và có chiến lược khác biệt. Qua phân tích Năm áp lực cạnh tranh, thị trường có mức độ cạnh tranh cao do sự tham gia của nhiều freelancer, dịch vụ thiết kế – truyền thông và sự xuất hiện của các công cụ thay thế như AI, Canva. Tuy nhiên, thị trường ngách sinh viên và các nhóm có ngân sách nhỏ vẫn còn tiềm năng vì thường xuyên phát sinh nhu cầu về thiết kế, content, video và truyền thông cho học tập, CLB, sự kiện và kinh doanh online. Vì vậy, PRiM nên tập trung vào giá phù hợp, dịch vụ trọn gói, quy trình linh hoạt và hiểu nhu cầu sinh viên, thay vì cạnh tranh trực tiếp với các agency lớn.

## 8. Điều chỉnh ý tưởng kinh doanh

| Nội dung | Ý tưởng ban đầu | Phát hiện từ thị trường / đối thủ / SWOT / Porter | Phiên bản điều chỉnh |
| --- | --- | --- | --- |
| Vấn đề khách hàng | Sinh viên gặp khó khăn trong việc thiết kế và thực hiện các sản phẩm truyền thông. | Khách hàng không chỉ thiếu kỹ năng mà còn hạn chế về thời gian và ngân sách, trong khi nếu thuê đơn vị chuyên nghiệp thì chi phí có thể cao. | Tập trung giải quyết nhu cầu có sản phẩm truyền thông đẹp, sáng tạo, chuyên nghiệp nhưng vẫn phù hợp với ngân sách sinh viên và giúp tiết kiệm thời gian. |
| Sản phẩm / dịch vụ | Cung cấp các dịch vụ thiết kế, viết content và hỗ trợ truyền thông. | Khách hàng có thể tự sử dụng Canva hoặc AI; nếu PRiM chỉ bán từng sản phẩm riêng lẻ thì dễ bị thay thế. File cũng xác định khách hàng cần nhiều loại hỗ trợ cùng lúc. | Phát triển combo dịch vụ truyền thông gồm thiết kế + content + kịch bản video + truyền thông sự kiện, tùy theo nhu cầu và ngân sách của khách hàng. |
| Khách hàng mục tiêu | Sinh viên và những người có nhu cầu sử dụng dịch vụ truyền thông. | Nghiên cứu cho thấy nhóm sinh viên, CLB, nhóm tổ chức sự kiện và người kinh doanh online nhỏ có nhu cầu thường xuyên nhưng ngân sách còn hạn chế. | Tập trung rõ vào sinh viên từ 18–24 tuổi, CLB, nhóm sinh viên và người kinh doanh online nhỏ. |
| Cách cạnh tranh | Cung cấp dịch vụ truyền thông với chi phí phù hợp. | Thị trường có nhiều freelancer, dịch vụ thiết kế và các công cụ thay thế như Canva, AI. Vì vậy, chỉ cạnh tranh bằng giá là chưa đủ. | PRiM cạnh tranh bằng giá phù hợp + dịch vụ trọn gói + cá nhân hóa + tiết kiệm thời gian + hiểu nhu cầu sinh viên. AI được sử dụng để hỗ trợ tăng tốc nhưng sản phẩm cuối cùng vẫn do con người kiểm tra và chỉnh sửa. |
- **Vấn đề lớn nhất nhóm phát hiện:**

Qua quá trình nghiên cứu, nhóm nhận thấy vấn đề cốt lõi không đơn thuần là sinh viên cần thiết kế poster hay viết content, mà là sinh viên cần những sản phẩm truyền thông đẹp và chuyên nghiệp nhưng có ngân sách hạn chế, đồng thời không phải lúc nào cũng có đủ thời gian và kỹ năng để tự thực hiện. Đây là khoảng cách mà PRiM hướng đến giải quyết bằng dịch vụ có chi phí phù hợp và tiết kiệm thời gian cho khách hàng. 

- **Điểm cần thay đổi nhất trong ý tưởng ban đầu:**

Điểm cần thay đổi là PRiM không nên chỉ tập trung vào việc cung cấp từng sản phẩm truyền thông riêng lẻ. Qua phân tích đối thủ và sản phẩm thay thế, nhóm nhận thấy khách hàng có thể tự thiết kế bằng Canva hoặc sử dụng AI. Vì vậy, PRiM cần chuyển sang hướng **cung cấp giải pháp truyền thông trọn gói**, kết hợp giữa lên ý tưởng, content, thiết kế và kịch bản. 

- **Có cần thay đổi khách hàng mục tiêu không? Vì sao?**

Nhóm không thay đổi hoàn toàn khách hàng mục tiêu, mà xác định rõ hơn phân khúc cần tập trung. PRiM tiếp tục hướng đến sinh viên, nhưng mở rộng cụ thể đến CLB, nhóm sinh viên và những người kinh doanh online nhỏ. Đây là những nhóm có nhu cầu sử dụng nội dung truyền thông nhưng thường có ngân sách hạn chế, phù hợp với định hướng của PRiM.

- **Có cần thay đổi cách cạnh tranh không? Vì sao?**

Có. Nhóm nhận thấy nếu chỉ cạnh tranh bằng giá thì PRiM sẽ khó tạo lợi thế lâu dài vì khách hàng có thể sử dụng Canva, AI hoặc tìm freelancer với nhiều mức giá khác nhau. Do đó, PRiM chuyển sang cạnh tranh bằng dịch vụ trọn gói, cá nhân hóa, tiết kiệm thời gian và hiểu môi trường sinh viên. Đây là những giá trị mà nhóm muốn kết hợp cùng mức giá phù hợp để tạo sự khác biệt.

- **Nhóm đồng ý / không đồng ý với đề xuất nào? Vì sao?**

Nhóm đồng ý với việc xây dựng các combo dịch vụ và sử dụng AI để hỗ trợ lên ý tưởng, viết nội dung và tạo bản nháp nhanh. Điều này giúp tiết kiệm thời gian và nâng cao năng suất của nhóm. Tuy nhiên, nhóm không đồng ý để AI tạo sản phẩm cuối cùng hoàn toàn mà không có sự kiểm tra của con người, vì sản phẩm truyền thông cần phù hợp với yêu cầu cụ thể của từng khách hàng và vẫn cần sự sáng tạo, chỉnh sửa

- **Mô tả ngắn gọn ý tưởng sau điều chỉnh:**

PRiM – Creative Content for Students là dịch vụ truyền thông dành cho sinh viên, CLB và người kinh doanh online nhỏ, cung cấp các combo thiết kế, content, kịch bản video và truyền thông sự kiện với mức giá phù hợp với ngân sách sinh viên. PRiM ứng dụng AI để hỗ trợ nghiên cứu, lên ý tưởng và tạo bản nháp nhanh, nhưng sản phẩm cuối cùng luôn được con người kiểm tra và chỉnh sửa. Dự án tạo sự khác biệt thông qua giá phù hợp, dịch vụ trọn gói, cá nhân hóa và tiết kiệm thời gian cho khách hàng

## 9. Phân tích tài chính dự kiến

**Đơn vị tiền tệ:** Việt Nam đồng (VNĐ)

**Đơn vị bán:** Gói dịch vụ/ đơn hàng

**Kỳ dự báo:** 1 tháng đầu tiên

**Cơ sở ước lượng số lượng bán mỗi tháng:** Giả định của nhóm dựa trên quy mô dự án nhỏ, khách hàng mục tiêu là sinh viên, CLB và người kinh doanh online nhỏ; PRiM định hướng mức giá phù hợp với ngân sách sinh viên

### 9.1. Chi phí khởi đầu (chi một lần)

| Khoản chi | Số tiền (VNĐ) | Cách ước tính / nguồn | Cần thiết ngay? |
| --- | --- | --- | --- |
| Thiết kế và xây dựng nhận diện ban đầu | 3.000.000 | Giả định | Có |
| Quảng bá trên mạng xã hội | 3.500.000 | Giả định | Có |
| In ấn và tài liệu giới thiệu | 1.500.000 | Giả định | Có  |
| Chi phí vận hành ban đầu | 4.000.000 | Giả định | Có  |
| Tổng chi phí khởi đầu | 15.000.000 | Tổng các khoản chi dụ kiến | Có |

### 9.2. Giá bán và doanh thu dự kiến mỗi tháng

| Sản phẩm / dịch vụ | Giá bán mỗi đơn vị | Số lượng bán dự kiến / tháng | Doanh thu dự kiến / tháng | Căn cứ cho giá và số lượng |
| --- | --- | --- | --- | --- |
| Thiết kế poster, banner, thiệp mời | 250.000 | 15 | 3.750.000 | Giả định của nhóm, phù hợp với khách hàng sinh viên |
| Viết content Facebook/TikTok/Instagram | 300.000 | 10 | 3.000.000 | Giả định của nhóm, phù hợp với khách hàng sinh viên |
| Lên ý tưởng + viết kịch bản video ngắn | 400.000 | 8 | 3.200.000 | Giả định của nhóm, phù hợp với khách hàng sinh viên |
| Combo truyền thông sự kiện/dự án sinh viên | 1.500.000 | 6 | 9.000.000 | Giả định của nhóm, phù hợp với khách hàng sinh viên |
| **TỔNG** |  | **39 đơn vị** | **18.950.000 VNĐ/tháng** |  |

### 9.3. Chi phí vận hành mỗi tháng

| Khoản chi | Loại chi phí | Cách tính | Số tiền / tháng | Nguồn / giả định |
| --- | --- | --- | --- | --- |
| Chi phí hỗ trợ thực hiện đơn hàng | Biến đổi theo đơn vị bán | 10% × 18.950.000 doanh thu/tháng | 1.895.000 | Giả định của nhóm |
| Chi phí chỉnh sửa / phát sinh | Biến đổi theo đơn vị bán | 100.000 × 10 đơn hàng/tháng | 1.000.000 | Giả định của nhóm |
| Quảng bá trên mạng xã hội | Cố định mỗi tháng | 500.000/tuần × 4 tuần | 2.000.000 | Giả định của nhóm |
| Phần mềm và công cụ hộ trợ | Cố định mỗi tháng | 375.000/tuần × 4 tuần | 1.500.000 | Giả định của nhóm |
| Internet và liên lạc | Cố định mỗi tháng | 125.000/tuần × 4 tuần | 500.000 | Giả định của nhóm |
| Chí phí vân hành khác | Cố định mỗi tháng | 250.000/tuần × 4 tuần | 1.000.000 | Giả định của nhóm |
| **Tổng chi phí biến đổi** |  | **1.895.000 + 1.000.000** | **2.895.000** |  |
| **Tổng chi phí cố định** |  | **2.000.000 + 1.500.000 + 500.000 + 1.000.000** | **5.000.000** |  |
| **TỔNG CHI PHÍ/ THÁNG**  |  | **2.895.000 + 5.000.000** | **7.895.000** |  |

### 9.4. Kết quả dự kiến và điểm hòa vốn

**Doanh thu dự kiến mỗi tháng:**

$$
\text{Doanh thu/tháng}=\sum_{i=1}^{n}\bigl(\text{Giá bán}_i\times\text{Số lượng bán}_i\bigr)
$$

Poster/banner: 250.000 × 15 = **3.750.000 VNĐ**

Content: 300.000 × 10 = **3.000.000 VNĐ**

Kịch bản video: 400.000 × 8 = **3.200.000 VNĐ**

Combo truyền thông: 1.500.000 × 6 = **9.000.000 VNĐ**

**Doanh thu/tháng = 3.750.000 + 3.000.000 + 3.200.000 + 9.000.000**

**= 18.950.000 VNĐ/tháng**

$$
\text{Số dư đảm phí/tháng}=\text{Doanh thu/tháng}-\text{Chi phí biến đổi/tháng}
$$

Thay số và kết quả: 

**18.950.000 – 2.895.000 = 16.055.000 VNĐ/tháng**

**Lợi nhuận hoạt động dự kiến mỗi tháng**

$$
\text{Lợi nhuận hoạt động/tháng}=\text{Doanh thu/tháng}-\text{Chi phí biến đổi/tháng}-\text{Chi phí cố định/tháng}
$$

Thay số và kết quả:

**18.950.000 − 2.895.000 − 5.000.000 = 11.055.000 VNĐ/tháng**

**Kết quả: Lợi nhuận hoạt động dự kiến = 11.055.000 VNĐ/tháng.**

**Điểm hòa vốn theo số đơn vị bán mỗi tháng** *(chỉ dùng trực tiếp khi bán một sản phẩm hoặc một gói cố định)*

$$
\text{Số đơn vị hòa vốn/tháng}=\left\lceil\frac{\text{Chi phí cố định/tháng}}{\text{Giá bán/đơn vị}-\text{Chi phí biến đổi/đơn vị}}\right\rceil
$$

Thay số và kết quả (làm tròn lên đơn vị nguyên): 

### **Tính giá bán bình quân/đơn vị**

Tổng doanh thu: **18.950.000 VNĐ**

Tổng số đơn vị bán: **39 đơn vị**

**= 18.950.000 ÷ 39 = 485.897 VNĐ/đơn vị**

### Tính chi phí biến đổi bình quân/đơn vị

Tổng chi phí biến đổi: **2.895.000 VNĐ**

**2.895.000 ÷ 39 = 74.231 VNĐ/đơn vị**

### Tính điểm hòa vốn

5.000.000 ÷ (485.897 − 74.231)

= 5.000.000 ÷ 411.666

= **12,15 đơn vị**

### **Điểm hòa vốn ≈ 13 đơn vị/tháng**

**5.000.000 ÷ [(18.950.000 ÷ 39) − (2.895.000 ÷ 39)] = 12,15 ≈ 13 đơn vị/tháng.**

**15.000.000 ÷ 11.055.000 = 1,36 tháng**

**Thời gian thu hồi vốn dự kiến ≈ 1,4 tháng.**

Nếu giá bán **nhỏ hơn hoặc bằng** chi phí biến đổi mỗi đơn vị, ghi “Chưa thể hòa vốn theo mô hình hiện tại” và giải thích cách điều chỉnh.

**Thời gian thu hồi chi phí khởi đầu (ước tính đơn giản, tùy chọn)**

$$
\text{Số tháng thu hồi vốn}=\frac{\text{Chi phí khởi đầu}}{\text{Lợi nhuận hoạt động/tháng}}
$$

Chỉ tính khi lợi nhuận hoạt động dự kiến mỗi tháng **lớn hơn 0**. Kết quả: **15.000.000 ÷ 11.055.000 = 1,36 tháng**

**Thời gian thu hồi vốn dự kiến ≈ 1,4 tháng.**

Nếu giá bán **nhỏ hơn hoặc bằng** chi phí biến đổi mỗi đơn vị, ghi “Chưa thể hòa vốn theo mô hình hiện tại” và giải thích cách điều chỉnh.

Đây là ước tính đơn giản dựa trên giả định lợi nhuận mỗi tháng không đổi; không phải cam kết thu hồi vốn. Chi phí khởi đầu ở mục 9.1 **không trừ lại** trong công thức lợi nhuận hoạt động mỗi tháng.

### 9.5. Kiểm tra giả định và quyết định của nhóm

| Giả định quan trọng | Căn cứ hiện có | Nếu kết quả thấp hơn dự kiến, nhóm sẽ làm gì? |
| --- | --- | --- |
| Số lượng dịch vụ bán mỗi tháng đạt khoảng 39 đơn vị | Dựa trên giả định của nhóm về nhu cầu của sinh viên, CLB, nhóm sinh viên và người kinh doanh online nhỏ – là các nhóm khách hàng mục tiêu của PRiM. | Nếu số lượng đơn hàng thấp hơn dự kiến, nhóm sẽ tăng cường quảng bá trên mạng xã hội, giới thiệu các combo có mức giá phù hợp và tập trung vào những dịch vụ có nhu cầu cao hơn. |
| Giá bán phù hợp với khả năng chi trả của khách hàng mục tiêu | Giá bán được nhóm giả định dựa trên đặc điểm khách hàng mục tiêu là sinh viên và các nhóm có ngân sách hạn chế. | Nếu khách hàng cho rằng giá cao hoặc tỷ lệ chốt đơn thấp, nhóm sẽ xem xét điều chỉnh gói dịch vụ, giảm phạm vi dịch vụ trong từng gói hoặc xây dựng thêm các gói có mức giá thấp hơn. |
| Doanh thu dự kiến đạt khoảng 18.950.000 VNĐ/tháng | Tính từ giá bán và số lượng dịch vụ dự kiến bán trong tháng. | Nếu chi phí thực tế cao hơn dự kiến, nhóm sẽ ưu tiên các khoản chi cần thiết, cắt giảm những khoản chưa cấp thiết và tối ưu việc sử dụng công cụ, phần mềm. |
| Chi phí vận hành khoảng 7.895.000 VNĐ/tháng | Dựa trên các khoản chi phí biến đổi và cố định do nhóm giả định cho hoạt động của PRiM. | Nếu chi phí thực tế cao hơn dự kiến, nhóm sẽ ưu tiên các khoản chi cần thiết, cắt giảm những khoản chưa cấp thiết và tối ưu việc sử dụng công cụ, phần mềm. |

**Kết quả tài chính có làm nhóm thay đổi ý tưởng hoặc quyết định cuối cùng không? Vì sao?** [Điền nội dung]

## 10. Tài liệu tham khảo

1. DataReportal. *Digital 2025: Vietnam*. [DataReportal – Digital 2025: Vietnam](https://datareportal.com/reports/digital-2025-vietnam?utm_source=chatgpt.com). Truy cập ngày 02/10/2026.
2. Canva. *Visual Communication Tools*. [Canva – Visual Communication Tools](https://www.canva.com/solutions/visual-communication-tools/?utm_source=chatgpt.com). Truy cập ngày 02/10/2026.
3. Canva. *Canva Pricing*. [Canva – Pricing](https://www.canva.com/pricing/?utm_source=chatgpt.com). Truy cập ngày 02/10/2026.
4. Upwork. *Hire Top Freelancers in Vietnam*. [Upwork – Hire Freelancers in Vietnam](https://www.upwork.com/hire/vn/?utm_source=chatgpt.com). Truy cập ngày 02/10/2026.
5. Upwork. *How to Find a Project in Project Catalog*. [Upwork – Project Catalog](https://support.upwork.com/hc/en-us/articles/4407894848659-How-to-find-a-project-in-Project-Catalog?utm_source=chatgpt.com). Truy cập ngày 02/10/2026.